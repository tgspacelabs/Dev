﻿CREATE TABLE [dbo].[DeviceSessions] (
    [Id]           UNIQUEIDENTIFIER NOT NULL,
    [DeviceId]     UNIQUEIDENTIFIER NULL,
    [BeginTimeUTC] DATETIME         NULL,
    [EndTimeUTC]   DATETIME         NULL,
    CONSTRAINT [PK_DeviceSessions_Id] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 100)
);
















GO
CREATE NONCLUSTERED INDEX [IX_DeviceSessions_DeviceId]
    ON [dbo].[DeviceSessions]([DeviceId] ASC) WITH (FILLFACTOR = 100);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Device session', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'DeviceSessions';


GO
CREATE NONCLUSTERED INDEX [IX_DeviceSessions_EndTimeUTC]
    ON [dbo].[DeviceSessions]([EndTimeUTC] ASC) WITH (FILLFACTOR = 100);


GO
ALTER INDEX [IX_DeviceSessions_EndTimeUTC]
    ON [dbo].[DeviceSessions] DISABLE;




GO
CREATE NONCLUSTERED INDEX [IX_DeviceSessions_EndTimeUTC_DeviceId]
    ON [dbo].[DeviceSessions]([EndTimeUTC] ASC)
    INCLUDE([DeviceId]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [IX_DeviceSessions_DeviceId_Id_BeginTimeUTC]
    ON [dbo].[DeviceSessions]([DeviceId] ASC)
    INCLUDE([Id], [BeginTimeUTC]) WITH (FILLFACTOR = 100);


GO
ALTER INDEX [IX_DeviceSessions_DeviceId_Id_BeginTimeUTC]
    ON [dbo].[DeviceSessions] DISABLE;






GO
CREATE NONCLUSTERED INDEX [IX_DeviceSessions_EndTimeUTC_DeviceId_BeginTimeUTC]
    ON [dbo].[DeviceSessions]([EndTimeUTC] ASC)
    INCLUDE([DeviceId], [BeginTimeUTC]) WITH (FILLFACTOR = 100);

