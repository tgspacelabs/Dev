﻿--DROP PROCEDURE [dbo].[GetPatientVitalsByTypeUpdatesX]
CREATE PROCEDURE [dbo].[GetPatientVitalsByTypeUpdatesX]
    (
     @patient_id UNIQUEIDENTIFIER,
     @types [dbo].[TypeCode] READONLY,
     @seq_num_after BIGINT,
     @dateAfter BIGINT
    )
AS
BEGIN
    DECLARE @l_dateAfter DATETIME = [dbo].[fnFileTimeToDateTime](@dateAfter);

    SELECT
        [t].[Type],
        [RESULT].[result_value] AS [VALUE],
        CAST(NULL AS DATETIME) AS [RESULT_TIME],
        [RESULT].[Sequence] AS [SEQ_NUM],
        [RESULT].[result_ft] AS [RESULT_FILE_TIME],
        CAST(1 AS BIT) AS [IS_RESULT_LOCALIZED]
    FROM
        [dbo].[int_result] AS [RESULT]
        INNER JOIN [dbo].[int_misc_code] AS [CODE]
            ON [RESULT].[test_cid] = [CODE].[code_id]
        INNER JOIN @types AS [t]
            ON [RESULT].[test_cid] = [t].[Type]
               AND [CODE].[code_id] = [t].[Type]
    WHERE
        [RESULT].[patient_id] = @patient_id
        AND [RESULT].[Sequence] > @seq_num_after
    UNION ALL
    SELECT
        [t].[Type],
        [vd].[Value] AS [VALUE],
        CAST(NULL AS DATETIME) AS [RESULT_TIME],
        0 AS [SEQ_NUM],
        [RESULT_FILE_TIME].[FileTime] AS [RESULT_FILE_TIME],
        CAST(0 AS BIT) AS [IS_RESULT_LOCALIZED]
    FROM
        [dbo].[VitalsData] AS [vd]
        INNER JOIN [dbo].[GdsCodeMap] AS [gcm]
            ON [gcm].[FeedTypeId] = [vd].[FeedTypeId]
               AND [gcm].[Name] = [vd].[Name]
        INNER JOIN [dbo].[TopicSessions] AS [ts]
            ON [ts].[Id] = [vd].[TopicSessionId]
        INNER JOIN @types AS [t]
            ON [gcm].[CodeId] = [t].[Type]
        CROSS APPLY [dbo].[fntDateTimeToFileTime]([TimestampUTC]) AS [RESULT_FILE_TIME]
    WHERE
        [ts].[PatientSessionId] IN (SELECT
                                        [PatientSessionId]
                                    FROM
                                        [dbo].[PatientSessionsMap]
                                        INNER JOIN (SELECT
                                                        MAX([Sequence]) AS [MaxSeq]
                                                    FROM
                                                        [dbo].[PatientSessionsMap]
                                                    GROUP BY
                                                        [PatientSessionId]
                                                   ) AS [PatientSessionMaxSeq]
                                            ON [Sequence] = [PatientSessionMaxSeq].[MaxSeq]
                                    WHERE
                                        [PatientId] = @patient_id)
        AND ([vd].[TimestampUTC] > @l_dateAfter)
    ORDER BY
        [RESULT_FILE_TIME] ASC;
END;