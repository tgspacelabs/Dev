﻿CREATE PROCEDURE [dbo].[usp_RemoveTrailingLiveData]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @PurgeDate DATETIME = SYSDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @RowCount BIGINT = @ChunkSize;
    DECLARE @TotalRows BIGINT = 0;
    DECLARE @GrandTotal BIGINT = 0;
    DECLARE @Message VARCHAR(200) = '';
    DECLARE @Flag BIT = 1;
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @Multiple TINYINT = 100;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(40)) + ' - Starting LiveData purge...';
        RAISERROR (@Message, 10, 1) WITH NOWAIT;

        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Chunk Size: %d', 10, 1, @DateString, @ChunkSize) WITH NOWAIT;
    END;

    IF (OBJECT_ID(N'tempdb..#CutoffRows') IS NOT NULL)
    BEGIN
        DROP TABLE [#CutoffRows];
    END;
        
    SELECT
        [ld].[TopicInstanceId],
        [ld].[FeedTypeId],
        DATEADD(SECOND, -150, MAX([ld].[TimestampUTC])) AS [LatestUTC]
    INTO
        [#CutoffRows]
    FROM
        [dbo].[LiveData] AS [ld]
    GROUP BY
        [ld].[TopicInstanceId],
        [ld].[FeedTypeId];

    CREATE CLUSTERED INDEX [IX_Cutoff_TopicInstanceId_FeedTypeId]
    ON [#CutoffRows] ( [TopicInstanceId] ASC, [FeedTypeId] ASC )
    WITH (FILLFACTOR = 100);
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ld]
            FROM
                [dbo].[LiveData] AS [ld] WITH (ROWLOCK) -- Do not allow lock escalations.
                INNER JOIN [#CutoffRows] AS [TopicFeedLatestToKeep]
                    ON [ld].[TopicInstanceId] = [TopicFeedLatestToKeep].[TopicInstanceId]
                       AND [ld].[FeedTypeId] = [TopicFeedLatestToKeep].[FeedTypeId]
            WHERE
                [ld].[TimestampUTC] < [TopicFeedLatestToKeep].[LatestUTC];

            --DELETE TOP (@ChunkSize)
            --    [ld]
            --FROM
            --    [dbo].[LiveData] AS [ld] WITH (ROWLOCK) -- Do not allow lock escalations.
            --    INNER JOIN (SELECT
            --                    [ld2].[TopicInstanceId],
            --                    [ld2].[FeedTypeId],
            --                    DATEADD(SECOND, -150, MAX([ld2].[TimestampUTC])) AS [LatestUTC]
            --                FROM
            --                    [dbo].[LiveData] AS [ld2]
            --                GROUP BY
            --                    [ld2].[TopicInstanceId],
            --                    [ld2].[FeedTypeId]
            --               ) AS [TopicFeedLatestToKeep]
            --        ON [ld].[TopicInstanceId] = [TopicFeedLatestToKeep].[TopicInstanceId]
            --           AND [ld].[FeedTypeId] = [TopicFeedLatestToKeep].[FeedTypeId]
            --WHERE
            --    [ld].[TimestampUTC] < [TopicFeedLatestToKeep].[LatestUTC];

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    EXEC [dbo].[uspInsertPurgerLog] @Procedure = @Procedure, @Table = N'LiveData', @PurgeDate = @PurgeDate,
        @Parameters = '1st pass', @ChunkSize = @ChunkSize, @Rows = @TotalRows, @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage, @StartTime = @StartTime;

    -- Delete any other live data older than 10 days
    SET @PurgeDate = DATEADD(DAY, -10, SYSUTCDATETIME());
    SET @RowCount = @ChunkSize;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @Flag = 1;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize) -- TOP is not allowed in an UPDATE or DELETE statement against a partitioned view.
                [ld]
            FROM
                [dbo].[LiveData] AS [ld] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [ld].[TimestampUTC] < @PurgeDate;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            WAITFOR DELAY '00:00:01';
    
            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
            RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    EXEC [dbo].[uspInsertPurgerLog] @Procedure = @Procedure, @Table = N'LiveData', @PurgeDate = @PurgeDate,
        @Parameters = '2nd pass', @ChunkSize = @ChunkSize, @Rows = @TotalRows, @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage, @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d', 10, 1, @DateString, @GrandTotal) WITH NOWAIT;

        SET @Message = CAST(SYSDATETIME() AS VARCHAR(40)) + ' - Ending LiveData purge...';
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20))
           + ') purged from ICS (' + @Procedure + ') at configured UTC time interval : '
           + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Remove the live data attached to a topic instance that is over 2.5 minutes old.  Then delete any live data that is more than 10 days old.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_RemoveTrailingLiveData';

