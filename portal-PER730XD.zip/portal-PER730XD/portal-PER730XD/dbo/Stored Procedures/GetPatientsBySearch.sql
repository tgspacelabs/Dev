﻿CREATE PROCEDURE [dbo].[GetPatientsBySearch]
    (
     @last_name [dbo].[DLAST_NAME],
     @first_name [dbo].[DFIRST_NAME],
     @mrn_id [dbo].[DMRN_ID],
     @login_name NVARCHAR(64),
     @is_vip_searchable NVARCHAR(4),
     @is_restricted_unit_searchable NVARCHAR(4),
     @Debug BIT = 0
    )
AS
BEGIN
    DECLARE
        @QUERY NVARCHAR(4000),
        @CONDITION NVARCHAR(1000);

    SET @QUERY = N'
SELECT
    [imm].[patient_id] AS [patient_id],
    ISNULL([ipe].[last_nm], N'''') + ISNULL(N'', '' + [ipe].[first_nm], N'''') AS [patient_name],
    [im].[monitor_name] AS [MONITOR_NAME],
    [imm].[mrn_xid2] AS [ACCOUNT_ID],
    [imm].[mrn_xid] AS [MRN_ID],
    [ORG1].[organization_id] AS [UNIT_ID],
    [ORG1].[organization_cd] AS [UNIT_NAME],
    [ORG2].[organization_id] AS [FACILITY_ID],
    [ORG2].[organization_nm] AS [FACILITY_NAME],
    [ipa].[dob] AS [DOB],
    [ie].[admit_dt] AS [ADMIT_TIME],
    [ie].[discharge_dt] AS [DISCHARGED_TIME],
    [ipm].[last_result_dt] AS [PRECEDENCE],
    [ipm].[patient_monitor_id] AS [PATIENT_MONITOR_ID],
    CASE WHEN [ie].[discharge_dt] IS NULL THEN ''A''
         ELSE ''D''
    END AS [STATUS]
FROM
    [dbo].[int_patient_monitor] AS [ipm]
    INNER JOIN [dbo].[int_encounter] AS [ie]
        ON [ie].[encounter_id] = [ipm].[encounter_id]
    INNER JOIN [dbo].[int_monitor] AS [im]
        ON [ipm].[monitor_id] = [im].[monitor_id]
    INNER JOIN [dbo].[int_organization] AS [ORG1]
        ON ([im].[unit_org_id] = [ORG1].[organization_id])
    INNER JOIN [dbo].[int_mrn_map] AS [imm]
        ON [ie].[patient_id] = [imm].[patient_id]
           AND [imm].[merge_cd] = ''C''
    INNER JOIN [dbo].[int_person] AS [ipe]
        ON [ie].[patient_id] = [ipe].[person_id]
    INNER JOIN [dbo].[int_patient] AS [ipa]
        ON [ie].[patient_id] = [ipa].[patient_id]
    LEFT OUTER JOIN [dbo].[int_account] AS [ia]
        ON [ie].[account_id] = [ia].[account_id]
    LEFT OUTER JOIN [dbo].[int_organization] AS [ORG2]
        ON [ORG2].[organization_id] = [ORG1].[parent_organization_id]
 ';

    -- Convert * to percentile in variables
    SET @last_name = LTRIM(RTRIM(@last_name));

    SET @first_name = LTRIM(RTRIM(@first_name));

    SET @mrn_id = LTRIM(RTRIM(@mrn_id));

    SET @CONDITION = ISNULL(@CONDITION, N'');

    -- Unit accessibility
    IF (@is_restricted_unit_searchable <> N'1')
    BEGIN
        SET @CONDITION += N' ORG1.organization_id 
                    NOT IN (SELECT [cro].[organization_id] FROM [dbo].[cdr_restricted_organization] AS [cro] 
                    WHERE [cro].[user_role_id] = 
                    (SELECT [iu].[user_role_id] FROM [dbo].[int_user] AS [iu] WHERE [iu].[login_name] = N'''
            + @login_name + '''))';
    END;

    --Last name
    IF (LEN(@last_name) > 0)
    BEGIN
       
        SET @last_name = REPLACE(@last_name, N'*', N'%');
        SET @last_name = QUOTENAME(@last_name, N'''');

        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND ';

        SET @CONDITION += N' ([ipe].[last_nm] LIKE N' + @last_name + N')';
    END;

    --First name
    IF (LEN(@first_name) > 0)
    BEGIN
       
        SET @first_name = REPLACE(@first_name, N'*', N'%');
        SET @first_name = QUOTENAME(@first_name, N'''');

        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND ';

        SET @CONDITION += N' ([ipe].[first_nm] LIKE N' + @first_name + N')';
    END;

    /*
    IF (LEN(@patient_id) > 0)
    BEGIN
        SET @patient_id = REPLACE(@patient_id, '*', '%')

        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND '

        SET @CONDITION += N' ([ipa].[patient_id] LIKE ''' + @patient_id + N''')'
    END 
    */

    --MRN ID
    IF (LEN(@mrn_id) > 0)
    BEGIN
        SET @mrn_id = QUOTENAME(@mrn_id, N'''');
        
        SET @mrn_id = REPLACE(@mrn_id, N'\', N'\\');
        SET @mrn_id = REPLACE(@mrn_id, N'[', N'\[');
        SET @mrn_id = REPLACE(@mrn_id, N']', N'\]');
        SET @mrn_id = REPLACE(@mrn_id, N'_', N'\_');
        SET @mrn_id = REPLACE(@mrn_id, N'%', N'\%');
        SET @mrn_id = REPLACE(@mrn_id, N'^', N'\^');
        SET @mrn_id = REPLACE(@mrn_id, N'*', N'%');

        IF (LEN(@CONDITION) > 0)
        BEGIN
            SET @CONDITION += N' AND ';
        END;

        SET @CONDITION += N' ([imm].[mrn_xid] LIKE ' + @mrn_id + N' ESCAPE ''\'')';
    END;

    --Check for VIP Patient
    IF (@is_vip_searchable <> N'1')
    BEGIN
        IF (LEN(@CONDITION) > 0)
        BEGIN
            SET @CONDITION += N' AND ';
        END;

        SET @CONDITION += N'[ie].[vip_sw] IS NULL';
    END;

    --Add condition
    IF (LEN(@CONDITION) > 0)
    BEGIN
        SET @QUERY += N' WHERE ';
        SET @QUERY += @CONDITION;
    END;

    -- Add a separate query for dataloader patients
    SET @QUERY += N'

UNION

SELECT
    [vsp].[patient_id],
    [vsp].[patient_name],
    [vsp].[MONITOR_NAME],
    [vsp].[ACCOUNT_ID],
    [vsp].[MRN_ID],
    [vsp].[UNIT_ID],
    [vsp].[UNIT_NAME],
    [vsp].[FACILITY_ID],
    [vsp].[FACILITY_NAME],
    [vsp].[DOB],
    [vsp].[ADMIT_TIME],
    [vsp].[DISCHARGED_TIME],
    [vsp].[ADMIT_TIME] AS [PRECEDENCE],
    [vsp].[PATIENT_MONITOR_ID],
    [vsp].[STATUS]
FROM
    [dbo].[v_StitchedPatients] AS [vsp]
 ';

    SET @CONDITION = N'';

     --Unit accessibility
    IF (@is_restricted_unit_searchable <> N'1')
    BEGIN
        SET @CONDITION += N' [UNIT_ID] 
                    NOT IN (SELECT [cro].[organization_id] FROM [dbo].[cdr_restricted_organization] AS [cro] 
                    WHERE [cro].[user_role_id] = 
                    (SELECT [iu].[user_role_id] FROM [dbo].[int_user] AS [iu] WHERE [iu].[login_name] = N'''
            + @login_name + N'''))';
    END;

    --Last name
    IF (LEN(@last_name) > 0)
    BEGIN
    
        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND ';

        SET @CONDITION += N' (LTRIM(RTRIM([LAST_NAME])) LIKE N' + @last_name + N')';
    END;

    --First name
    IF (LEN(@first_name) > 0)
    BEGIN

        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND ';

        SET @CONDITION += N' (LTRIM(RTRIM([FIRST_NAME])) LIKE N' + @first_name + N')';
    END;

    --MRN ID
    IF (LEN(@mrn_id) > 0)
    BEGIN

        IF (LEN(@CONDITION) > 0)
            SET @CONDITION += N' AND ';

        SET @CONDITION += N' (LTRIM(RTRIM([MRN_ID])) LIKE N' + @mrn_id + N' ESCAPE ''\'')';
    END;

    --Add condition
    IF (LEN(@CONDITION) > 0)
    BEGIN
        SET @QUERY += N' WHERE [vsp].[patient_id] IS NOT NULL AND ';
        SET @QUERY += @CONDITION;
    END;

    SET @QUERY += N'
ORDER BY 
    [ADMIT_TIME] DESC, 
    [PRECEDENCE] DESC,
    [STATUS],
    [patient_name],
    [MONITOR_NAME]
OPTION (RECOMPILE);';

    IF (@Debug = 1)
    BEGIN
        PRINT @QUERY;
    END;

    EXEC (@QUERY);
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Search for patients by last name, first name, medical record number (MRN), VIP status and restricted unit.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'GetPatientsBySearch';

