﻿CREATE PROCEDURE [dbo].[usp_GetDebugSettings_FromDb]
AS
BEGIN
    SELECT
        [iec].[track_alarm_execution],
        [iec].[track_vitals_update_execution]
    FROM
        [dbo].[int_event_config] AS [iec];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_GetDebugSettings_FromDb';

