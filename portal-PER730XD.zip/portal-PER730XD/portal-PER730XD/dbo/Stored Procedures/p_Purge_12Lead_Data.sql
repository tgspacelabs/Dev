﻿CREATE PROCEDURE [dbo].[p_Purge_12Lead_Data]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @Flag BIT = 1;
    DECLARE @RowCount INT = 0;
    DECLARE @TotalRows BIGINT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @DateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    
    EXEC [dbo].[PurgerParameters]
        @Name = 'TwelveLead',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;

    IF (@Debug = 1)
    BEGIN
        DECLARE @Message VARCHAR(200) = '';
        DECLARE @Multiple TINYINT = 10;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Starting...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [isew]
            FROM
                [dbo].[int_saved_event_waveform] AS [isew] WITH (ROWLOCK) -- Do not allow lock escalations.
                INNER JOIN [dbo].[int_saved_event] AS [ise]
                    ON [isew].[event_id] = [ise].[event_id]
                       AND [isew].[patient_id] = [ise].[patient_id]
            WHERE
                [ise].[insert_dt] < @PurgeDate;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_saved_event_waveform',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    -- Nancy on 2/28/08, Fix for CR Isq#2661
    -- Don't handle parent table data here since other child table data need them 
    --    SET ROWCOUNT 0
    --    DELETE FROM [dbo].[int_patient_monitor]
    --    FROM [dbo].[int_encounter] ie
    --    WHERE int_patient_monitor.encounter_id = ie.encounter_id
    --    AND discharge_dt < @PurgeDate
    --    AND isnull(active_sw, 0) = 0;
    --    SET @RC += @@ROWCOUNT;

    SET @Flag = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ilre]
            FROM
                [dbo].[int_12lead_report_edit] AS [ilre]
                INNER JOIN [dbo].[int_12lead_report] AS [i12r]
                    ON [ilre].[report_id] = [i12r].[report_id]
            WHERE
                [i12r].[report_dt] < @PurgeDate;
            
            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_12lead_report_edit',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Flag = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ipt]
            FROM
                [dbo].[int_param_timetag] AS [ipt]
            WHERE
                [ipt].[param_dt] < @PurgeDate;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_param_timetag',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Flag = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ise]
            FROM
                [dbo].[int_SavedEvent] AS [ise]
            WHERE
                [ise].[insert_dt] < @PurgeDate;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_SavedEvent',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Flag = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ilr]
            FROM
                [dbo].[int_12lead_report] AS [ilr]
            WHERE
                [ilr].[report_dt] < @PurgeDate;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
            IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_12lead_report',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Finished...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'p_Purge_12Lead_Data';

