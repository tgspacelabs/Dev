﻿CREATE PROCEDURE [dbo].[p_Purge_WaveForm_Data] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);

    EXEC [dbo].[PurgerwaveformParameters]
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;
    --SET @PurgeDateUTC = DATEADD(HOUR, 1, [dbo].[fnLocalDateTimeToUtcTime](@PurgeDate)); -- add 1 hour as fnLocalDateTimeToUtcTime does not handle daylight savings shift well

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [wf]
            FROM
                [dbo].[int_waveform] AS [wf]
            WHERE
                [wf].[end_dt] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_waveform',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [at]
            FROM
                [dbo].[AnalysisTime] AS [at]
            WHERE
                [at].[insert_dt] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'AnalysisTime',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ipc]
            FROM
                [dbo].[int_patient_channel] AS [ipc]
                INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
                    ON [ipc].[patient_monitor_id] = [ipm].[patient_monitor_id]
                INNER JOIN [dbo].[int_encounter] AS [ie]
                    ON [ipm].[encounter_id] = [ie].[encounter_id]
            WHERE
                [ie].[discharge_dt] < @PurgeDate
                AND [ipc].[active_sw] IS NULL
                AND NOT EXISTS ( SELECT
                                    1
                                 FROM
                                    [dbo].[int_waveform] AS [iw]
                                 WHERE
                                    [iw].[patient_channel_id] = [ipc].[patient_channel_id] );

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_patient_channel',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;
GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Purge old waveform, analysis and patient channel data',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'p_Purge_WaveForm_Data';

