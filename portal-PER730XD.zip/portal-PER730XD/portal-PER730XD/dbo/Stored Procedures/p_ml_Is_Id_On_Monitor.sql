﻿CREATE PROCEDURE [dbo].[p_ml_Is_Id_On_Monitor]
    (
     @PatId AS VARCHAR(20),
     @CurrentMonitor AS VARCHAR(10) = ''
    )
AS
BEGIN
    IF (@CurrentMonitor IS NULL)
    BEGIN
        SET @CurrentMonitor = '';
    END;

    SELECT
        [ipm].[active_sw],
        [im].[monitor_name],
        [im].[standby]
    FROM
        [dbo].[int_mrn_map] AS [imm]
        LEFT OUTER JOIN [dbo].[int_patient_monitor] AS [ipm]
            ON ([imm].[patient_id] = [ipm].[patient_id]
                AND [ipm].[active_sw] = 1)
        LEFT OUTER JOIN [dbo].[int_monitor] AS [im]
            ON ([ipm].[monitor_id] = [im].[monitor_id])
    WHERE
        [imm].[mrn_xid] = @PatId
        AND [im].[monitor_name] <> @CurrentMonitor
        AND [ipm].[active_sw] = 1
        AND [imm].[merge_cd] = 'C'
        AND [im].[standby] IS NULL
    UNION
    SELECT TOP (1)
        CAST(1 AS TINYINT) AS [active_sw],
        N'ET' AS [monitor_name],
        CASE [MonitoringStatus].[Value]
          WHEN N'Standby' THEN 1
          ELSE NULL
        END AS [standby]
    FROM
        [dbo].[int_mrn_map] AS [imm]
        INNER JOIN [dbo].[v_PatientTopicSessions] AS [vpts]
            ON [vpts].[PatientId] = [imm].[patient_id]
        INNER JOIN [dbo].[TopicSessions] AS [ts]
            ON [ts].[Id] = [vpts].[TopicSessionId]
        LEFT OUTER JOIN (SELECT
                            [did].[DeviceSessionId],
                            [did].[Name],
                            [did].[Value],
                            ROW_NUMBER() OVER (PARTITION BY [did].[DeviceSessionId], [did].[Name] ORDER BY [did].[TimestampUTC] DESC) AS [RowNumber]
                         FROM
                            [dbo].[DeviceInfoData] AS [did]
                         WHERE
                            [did].[Name] = N'MonitoringStatus'
                        ) AS [MonitoringStatus]
            ON [MonitoringStatus].[DeviceSessionId] = [ts].[DeviceSessionId]
               AND [MonitoringStatus].[RowNumber] = 1
    WHERE
        [imm].[mrn_xid] = @PatId
        AND [ts].[EndTimeUTC] IS NULL;
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_ml_Is_Id_On_Monitor';

