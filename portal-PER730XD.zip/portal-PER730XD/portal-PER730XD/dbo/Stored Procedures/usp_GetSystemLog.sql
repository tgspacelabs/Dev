﻿CREATE PROCEDURE [dbo].[usp_GetSystemLog]
    (
     @filters NVARCHAR(MAX),
     @FromDate NVARCHAR(MAX), -- Should be DATETIME - TG
     @ToDate NVARCHAR(MAX), -- Should be DATETIME - TG
     @Debug BIT = 0
    )
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX) = N'
        SELECT
            [iml].[msg_dt] AS [Date],
            [iml].[product] AS [Product],
            [iml].[type] AS [Status],
            [iml].[msg_text] AS [Message]
        FROM
            [dbo].[int_msg_log] AS [iml]
        WHERE
            [iml].[msg_dt] BETWEEN ';
    SET @Query += N'''' + @FromDate + N'''';
    SET @Query += N' AND ';
    SET @Query += N'''' + @ToDate + N'''';
                                        
    IF (LEN(@filters) > 0)
    BEGIN
        SET @Query += N' AND ';
    END;

    SET @Query += @filters;

    IF (@Debug = 1)
    BEGIN
        PRINT @Query;
    END;
    
    EXEC(@Query);
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_GetSystemLog';

