﻿CREATE PROCEDURE [dbo].[GetPatientAlarmsByType]
    (
     @patient_id UNIQUEIDENTIFIER,
     @alarm_type INT,
     @start_ft BIGINT,
     @end_ft BIGINT
    )
AS
BEGIN
    SELECT
        [ia].[alarm_id] AS [ID],
        [ia].[alarm_cd] AS [TITLE],
        [ia].[start_ft] AS [start_ft],
        [ia].[end_ft] AS [end_ft],
        [ia].[start_dt] AS [START_DT],
        [ia].[removed],
        [ia].[alarm_level] AS [priority]
    FROM
        [dbo].[int_alarm] AS [ia]
        INNER JOIN [dbo].[int_patient_channel] AS [ipc]
            ON [ia].[patient_channel_id] = [ipc].[patient_channel_id]
        INNER JOIN [dbo].[int_channel_type] AS [ict]
            ON [ipc].[channel_type_id] = [ict].[channel_type_id]
    WHERE
        [ia].[patient_id] = @patient_id
        AND [ict].[channel_code] = @alarm_type
        AND ((@start_ft < [end_ft]
              AND @end_ft >= [start_ft])
             OR (@end_ft >= [start_ft]
                 AND [end_ft] IS NULL))
    ORDER BY
        [start_ft];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'GetPatientAlarmsByType';

