﻿CREATE PROCEDURE [dbo].[GetPatientVitalsTypes]
    (
     @patient_id UNIQUEIDENTIFIER
    )
AS
BEGIN
    SELECT
        [Code].[code_id] AS [TYPE],
        [Code].[code] AS [CODE],
        [Code].[int_keystone_cd] AS [UNITS]
    FROM
        [dbo].[int_misc_code] AS [Code]
        INNER JOIN (SELECT DISTINCT
                        [ir].[test_cid]
                    FROM
                        [dbo].[int_result] AS [ir]
                    WHERE
                        [ir].[patient_id] = @patient_id
                   ) AS [result_cid]
            ON [result_cid].[test_cid] = [Code].[code_id]
    UNION ALL
    SELECT DISTINCT
        [gcm].[CodeId] AS [TYPE],
        [gcm].[GdsCode] AS [CODE],
        [gcm].[Units] AS [UNITS]
    FROM
        [dbo].[GdsCodeMap] AS [gcm]
        INNER JOIN [dbo].[VitalsData] AS [vd]
            ON [gcm].[FeedTypeId] = [vd].[FeedTypeId]
               AND [gcm].[Name] = [vd].[Name]
        INNER JOIN [dbo].[TopicSessions] AS [ts]
            ON [ts].[Id] = [vd].[TopicSessionId]
        INNER JOIN [dbo].[PatientSessionsMap] AS [psm]
            ON [ts].[PatientSessionId] = [psm].[PatientSessionId]
        INNER JOIN (SELECT
                        MAX([psm2].[Sequence]) AS [MaxSeq]
                    FROM
                        [dbo].[PatientSessionsMap] AS [psm2]
                    GROUP BY
                        [psm2].[PatientSessionId]
                   ) AS [PatientSessionMaxSeq]
            ON [psm].[Sequence] = [PatientSessionMaxSeq].[MaxSeq]
    WHERE
        [psm].[PatientId] = @patient_id;
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Return the patients'' vitals types, codes and units.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'GetPatientVitalsTypes';

