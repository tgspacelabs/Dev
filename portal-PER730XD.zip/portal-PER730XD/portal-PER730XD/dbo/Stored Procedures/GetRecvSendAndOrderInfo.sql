﻿CREATE PROCEDURE [dbo].[GetRecvSendAndOrderInfo]
    (
     @patient_id UNIQUEIDENTIFIER
    )
AS
BEGIN
    SELECT
        [ig].[recv_app] AS [RECVAPP],
        [ig].[send_app] AS [SENDAPP],
        [iom].[order_xid] AS [ORDERXID],
        [ig].[send_app] AS [SENDAPP],
        [io].[univ_svc_cid] AS [ORDERSTATUS],
        [io].[order_dt] AS [TRANSDATETIME]
    FROM
        [dbo].[int_gateway] AS [ig]
        INNER JOIN [dbo].[int_monitor] AS [im]
            ON [ig].[network_id] = [im].[network_id]
        INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
            ON [im].[monitor_id] = [ipm].[monitor_id]
        INNER JOIN [dbo].[int_order_map] AS [iom]
            ON [ig].[send_sys_id] = [iom].[sys_id]
        INNER JOIN [dbo].[int_order] AS [io]
            ON [ipm].[patient_id] = [io].[patient_id]
               AND [io].[order_id] = [iom].[order_id]
    WHERE
        [ig].[gateway_type] <> 'S5N'
        AND [ipm].[patient_id] = @patient_id;
        --AND [ipm].[active_sw] = 1; 
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'GetRecvSendAndOrderInfo';

