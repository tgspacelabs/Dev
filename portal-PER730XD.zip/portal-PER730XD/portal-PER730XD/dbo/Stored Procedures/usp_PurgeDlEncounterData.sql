﻿CREATE PROCEDURE [dbo].[usp_PurgeDlEncounterData]
    (
     @ChunkSize INT = 1500,
     @DaysPrior TINYINT = 10,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    --DECLARE @PurgeDate DATETIME;
    --DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @PurgeDateTimeUTC DATETIME = DATEADD(DAY, (-1 * @DaysPrior), GETUTCDATE());
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @MessageDateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);

    -- No specific purge date
    --SET @PurgeDate = @StartTime;

    IF (@Debug = 1)
    BEGIN
        DECLARE @Message VARCHAR(200) = '';
        DECLARE @Multiple TINYINT = 10;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Starting...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ds]
            FROM
                [dbo].[DeviceSessions] AS [ds] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [ds].[EndTimeUTC] IS NOT NULL
                AND [ds].[EndTimeUTC] <= @PurgeDateTimeUTC;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @MessageDateString, @TotalRows) WITH NOWAIT;
                END;
            END;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'DeviceSessions',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [did]
            FROM
                [dbo].[DeviceInfoData] AS [did] WITH (ROWLOCK) -- Do not allow lock escalations.
                LEFT OUTER JOIN [dbo].[DeviceSessions] AS [ds]
                    ON [did].[DeviceSessionId] = [ds].[Id]
            WHERE
                [ds].[Id] IS NULL;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'DeviceInfoData',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ts]
            FROM
                [dbo].[TopicSessions] AS [ts] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [ts].[EndTimeUTC] IS NOT NULL
                AND [ts].[EndTimeUTC] <= @PurgeDateTimeUTC;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'TopicSessions',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [pd]
            FROM
                [dbo].[PatientData] AS [pd] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [pd].[PatientSessionId] IN (SELECT
                                                [ps].[Id]
                                            FROM
                                                [dbo].[PatientSessions] AS [ps]
                                            WHERE
                                                [ps].[EndTimeUTC] IS NOT NULL
                                                AND [ps].[EndTimeUTC] <= @PurgeDateTimeUTC)
                AND [pd].[TimestampUTC] <= @PurgeDateTimeUTC;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'PatientData',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ps]
            FROM
                [dbo].[PatientSessions] AS [ps] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [ps].[EndTimeUTC] IS NOT NULL
                AND [ps].[EndTimeUTC] <= @PurgeDateTimeUTC
                AND NOT EXISTS ( SELECT
                                    1
                                 FROM
                                    [dbo].[PatientData] AS [pd]
                                 WHERE
                                    [pd].[PatientSessionId] = [Id] );

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'PatientSessions',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [psm]
            FROM
                [dbo].[PatientSessionsMap] AS [psm] WITH (ROWLOCK) -- Do not allow lock escalations.
                LEFT OUTER JOIN [dbo].[PatientSessions] AS [ps]
                    ON [psm].[PatientSessionId] = [ps].[Id]
            WHERE
                [ps].[Id] IS NULL;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'PatientSessionsMap',
        @PurgeDate = @PurgeDateTimeUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured UTC time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDateTimeUTC, 121)) + '.');
END;
GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Purge Data Loader encounter data tables (DeviceSessions, DeviceInfoData, TopicSessions, PatientData, PatientSessions, PatientSessionsMap).',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'usp_PurgeDlEncounterData';

