﻿CREATE PROCEDURE [dbo].[p_gts_Input_Rate]
    (
     @MinutesTimeSlice AS INT = 15,
     @Save AS CHAR(1) = 'N',
     @referenceTime AS DATETIME = NULL
    )
AS
BEGIN
    SET DEADLOCK_PRIORITY LOW;

    DECLARE
        @cutoffdt AS DATETIME,
        @ucutoffdt AS DATETIME,
        @basetime AS DATETIME,
        @baseminute AS INT,
        @count AS INT;

    DECLARE @inprate TABLE
        (
         [input_type] VARCHAR(20),
         [period_start] DATETIME NOT NULL,
         [period_len] INT NOT NULL,
         [rate_counter] INT NOT NULL
        );

    IF (@MinutesTimeSlice IS NULL)
    BEGIN 
        SET @MinutesTimeSlice = 15;
    END;
        
    IF (@Save IS NULL)
    BEGIN
        SET @Save = 'N';
    END;
    ELSE
    BEGIN
        SET @Save = UPPER(@Save);
    END;

    IF (@referenceTime IS NULL)
    BEGIN
        SET @referenceTime = GETDATE();
    END;

    SET @basetime = DATEADD(HOUR, DATEDIFF(HOUR, 0, @referenceTime), 0);
    SET @baseminute = FLOOR(DATEPART(MINUTE, @referenceTime) / @MinutesTimeSlice) * @MinutesTimeSlice;

    SET @ucutoffdt = DATEADD(MINUTE, @baseminute, @basetime);
    SET @cutoffdt = DATEADD(MINUTE, -(@MinutesTimeSlice), @ucutoffdt);

    -- Monitor results
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_result] AS [ir]
    WHERE
        [ir].[obs_start_dt] >= @cutoffdt
        AND [ir].[obs_start_dt] < @ucutoffdt;

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('MonitorResults',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- Waveform
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_waveform] AS [iw]
    WHERE
        (([iw].[start_dt] >= @cutoffdt)
         AND ([iw].[start_dt] < @ucutoffdt));

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('WaveFormData',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- 12 Lead
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_param_timetag] AS [ipt]
    WHERE
        (([ipt].[param_dt] >= @cutoffdt)
         AND ([ipt].[param_dt] < @ucutoffdt));

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('TwelveLead',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- Alarm
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_alarm] AS [ia]
    WHERE
        [ia].[start_dt] >= @cutoffdt
        AND [ia].[start_dt] < @ucutoffdt;

    -- Saves Counter for
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('Alarm',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- MessageLog
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_msg_log] AS [iml]
    WHERE
        [iml].[msg_dt] >= @cutoffdt
        AND [iml].[msg_dt] < @ucutoffdt;

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('MsgLog',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- Print_Job
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_print_job] AS [ipj]
    WHERE
        [ipj].[job_net_dt] >= @cutoffdt
        AND [ipj].[job_net_dt] < @ucutoffdt;

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('PrintJob',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- Clinical Event Interface
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[int_event_log] AS [iel]
    WHERE
        [iel].[event_dt] >= @cutoffdt
        AND [iel].[event_dt] < @ucutoffdt;

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('CEILog',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- HL7 Success
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[HL7_out_queue] AS [hoq]
    WHERE
        [hoq].[sent_dt] >= @cutoffdt
        AND [hoq].[sent_dt] < @ucutoffdt
        AND [hoq].[msg_status] = N'R';

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('HL7Success',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- HL7 Error
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[HL7_out_queue] AS [hoq]
    WHERE
        [hoq].[sent_dt] >= @cutoffdt
        AND [hoq].[sent_dt] < @ucutoffdt
        AND [hoq].[msg_status] = N'E';

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('HL7Error',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- HL7 Not Read
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[HL7_out_queue] AS [hoq]
    WHERE
        [hoq].[sent_dt] >= @cutoffdt
        AND [hoq].[sent_dt] < @ucutoffdt
        AND [hoq].[msg_status] = N'N';

    -- Saves Counter
    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('HL7NotRead',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- HL7 Pending
    SELECT
        @count = COUNT(*)
    FROM
        [dbo].[HL7_out_queue] AS [hoq]
    WHERE
        [hoq].[sent_dt] >= @cutoffdt
        AND [hoq].[sent_dt] < @ucutoffdt
        AND [hoq].[msg_status] = N'P';

    INSERT  INTO @inprate
            ([input_type],
             [period_start],
             [period_len],
             [rate_counter])
    VALUES
            ('HL7Pending',
             @cutoffdt,
             @MinutesTimeSlice,
             @count);

    -- Saves Counter
    IF (@Save = 'Y')
    BEGIN
        IF NOT EXISTS ( SELECT TOP (1)
                            [gir].[period_len]
                        FROM
                            [dbo].[gts_input_rate] AS [gir]
                        WHERE
                            [gir].[period_start] = @cutoffdt
                            AND [gir].[period_len] = @MinutesTimeSlice )
        BEGIN
            INSERT  INTO [dbo].[gts_input_rate]
                    ([input_type],
                     [period_start],
                     [period_len],
                     [rate_counter])
            SELECT
                [i].[input_type],
                [i].[period_start],
                [i].[period_len],
                [i].[rate_counter]
            FROM
                @inprate AS [i];
        END;
    END;

    SELECT
        [i].[input_type],
        [i].[period_start],
        [i].[period_len],
        [i].[rate_counter]
    FROM
        @inprate AS [i];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_gts_Input_Rate';

