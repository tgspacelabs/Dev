﻿CREATE PROCEDURE [dbo].[p_Purge_Encounter_Data]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    --DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @DateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));

    -- No specific purge date
    SET @PurgeDate = @StartTime;

    BEGIN TRY
    -- Delete Encounter first as the root, then delete other leaves
        DELETE
            [iem]
        FROM
            [dbo].[int_encounter_map] AS [iem]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_encounter_map',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [id]
        FROM
            [dbo].[int_diagnosis] AS [id]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_diagnosis',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [idd]
        FROM
            [dbo].[int_diagnosis_drg] AS [idd]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_diagnosis_drg',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ig]
        FROM
            [dbo].[int_guarantor] AS [ig]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_guarantor',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [io]
        FROM
            [dbo].[int_order] AS [io]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_order',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [iom]
        FROM
            [dbo].[int_order_map] AS [iom]
        WHERE
            [order_id] NOT IN (SELECT
                                [io].[order_id]
                               FROM
                                [dbo].[int_order] AS [io]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_order_map',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [iol]
        FROM
            [dbo].[int_order_line] AS [iol]
        WHERE
            [order_id] NOT IN (SELECT
                                [io].[order_id]
                               FROM
                                [dbo].[int_order] AS [io]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_order_line',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ipld]
        FROM
            [dbo].[int_patient_list_detail] AS [ipld]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_patient_list_detail',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [iethi]
        FROM
            [dbo].[int_encounter_to_hcp_int] AS [iethi]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_encounter_to_hcp_int',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ieth]
        FROM
            [dbo].[int_encounter_tfr_history] AS [ieth]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_encounter_tfr_history',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ipm]
        FROM
            [dbo].[int_patient_monitor] AS [ipm]
        WHERE
            [encounter_id] NOT IN (SELECT
                                    [ie].[encounter_id]
                                   FROM
                                    [dbo].[int_encounter] AS [ie])
            AND ISNULL([ipm].[active_sw], 0) <> 1;

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_patient_monitor',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ia]
        FROM
            [dbo].[int_account] AS [ia]
        WHERE
            [account_id] NOT IN (SELECT
                                    [ie].[account_id]
                                 FROM
                                    [dbo].[int_encounter] AS [ie]);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_account',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE TOP (@ChunkSize)
            [ipc]
        FROM
            [dbo].[int_patient_channel] AS [ipc]
        WHERE
            [ipc].[patient_id] IN (SELECT
                                    [vpdsld].[PatientId]
                                   FROM
                                    [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                   WHERE
                                    [vpdsld].[DaysSinceLastDischarge] >= 10);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_patient_channel',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ip]
        FROM
            [dbo].[int_person] AS [ip]
        WHERE
            [ip].[person_id] IN (SELECT
                                    [vpdsld].[PatientId]
                                 FROM
                                    [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                 WHERE
                                    [vpdsld].[DaysSinceLastDischarge] >= 10);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_person',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ip]
        FROM
            [dbo].[int_patient] AS [ip]
        WHERE
            [ip].[patient_id] IN (SELECT
                                    [vpdsld].[PatientId]
                                  FROM
                                    [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                  WHERE
                                    [vpdsld].[DaysSinceLastDischarge] >= 10);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_patient',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ipn]
        FROM
            [dbo].[int_person_name] AS [ipn]
        WHERE
            [ipn].[person_nm_id] IN (SELECT
                                        [vpdsld].[PatientId]
                                     FROM
                                        [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                     WHERE
                                        [vpdsld].[DaysSinceLastDischarge] >= 10);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_person_name',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [imm]
        FROM
            [dbo].[int_mrn_map] AS [imm]
        WHERE
            [imm].[patient_id] IN (SELECT
                                    [vpdsld].[PatientId]
                                   FROM
                                    [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                   WHERE
                                    [vpdsld].[DaysSinceLastDischarge] >= 10);

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_mrn_map',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
        DELETE
            [ie]
        FROM
            [dbo].[int_encounter] AS [ie]
        WHERE
            [encounter_id] IN (SELECT
                                [ie2].[encounter_id]
                               FROM
                                [dbo].[int_encounter] AS [ie2]
                               WHERE
                                [ie2].[patient_id] IN (SELECT
                                                        [vpdsld].[PatientId]
                                                       FROM
                                                        [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]
                                                       WHERE
                                                        [vpdsld].[DaysSinceLastDischarge] >= 10));

        SET @TotalRows += @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_encounter',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    --BEGIN TRY
    --    DELETE
    --        [ie]
    --    FROM
    --        [dbo].[int_encounter] AS [ie]
    --    WHERE
    --        [encounter_id] NOT IN (SELECT
    --                                [ie2].[encounter_id]
    --                               FROM
    --                                [dbo].[int_encounter] AS [ie2]
    --                               WHERE
    --                                [ie2].[patient_id] IN (SELECT
    --                                                        [vpdsld].[PatientId]
    --                                                       FROM
    --                                                        [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]))
    --        AND [ie].[begin_dt] IS NOT NULL
    --        AND DATEDIFF(DAY, [ie].[begin_dt], GETDATE()) > 30; -- delete records that were never admitted to a device which are older than 30 days

    --    SET @TotalRows += @@ROWCOUNT;
    --END TRY
    --BEGIN CATCH
    --    SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    --    SET @ErrorNumber = ERROR_NUMBER();
    --    SET @ErrorMessage = ERROR_MESSAGE();
    --    RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

    --    --CONTINUE;
    --END CATCH;

    --EXEC [dbo].[uspInsertPurgerLog]
    --    @Procedure = @Procedure,
    --    @Table = N'int_encounter',
    --    @PurgeDate = @PurgeDate,
    --    @Parameters = '',
    --    @ChunkSize = @ChunkSize,
    --    @Rows = @TotalRows,
    --    @ErrorNumber = @ErrorNumber,
    --    @ErrorMessage = @ErrorMessage,
    --    @StartTime = @StartTime;

    --SET @GrandTotal += @TotalRows;
    --SET @TotalRows = 0;
    --SET @StartTime = SYSUTCDATETIME();

    --BEGIN TRY
    ---- Delete those rows which have a [begin_dt] that is NULL and use the [mod_dt] instead
    --    DELETE
    --        [ie]
    --    FROM
    --        [dbo].[int_encounter] AS [ie]
    --    WHERE
    --        [encounter_id] NOT IN (SELECT
    --                                [ie2].[encounter_id]
    --                               FROM
    --                                [dbo].[int_encounter] AS [ie2]
    --                               WHERE
    --                                [ie2].[patient_id] IN (SELECT
    --                                                        [vpdsld].[PatientId]
    --                                                       FROM
    --                                                        [dbo].[v_PatientDaysSinceLastDischarge] AS [vpdsld]))
    --        AND [ie].[begin_dt] IS NULL
    --        AND DATEDIFF(DAY, [ie].[mod_dt], GETDATE()) > 30; -- delete records that were never admitted to a device which are older than 30 days

    --    SET @TotalRows += @@ROWCOUNT;
    --END TRY
    --BEGIN CATCH
    --    SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    --    SET @ErrorNumber = ERROR_NUMBER();
    --    SET @ErrorMessage = ERROR_MESSAGE();
    --    RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

    --    --CONTINUE;
    --END CATCH;
    
    --EXEC [dbo].[uspInsertPurgerLog]
    --    @Procedure = @Procedure,
    --    @Table = N'int_encounter',
    --    @PurgeDate = @PurgeDate,
    --    @Parameters = '',
    --    @ChunkSize = @ChunkSize,
    --    @Rows = @TotalRows,
    --    @ErrorNumber = @ErrorNumber,
    --    @ErrorMessage = @ErrorMessage,
    --    @StartTime = @StartTime;

    --SET @GrandTotal += @TotalRows;
    --SET @TotalRows = 0;
    --SET @StartTime = SYSUTCDATETIME();

    BEGIN TRY
      -- Delete those rows which have a [monitor_created] value that is NULL and use the [mod_dt] instead
        WHILE (@Loop > 0)
        BEGIN
            DELETE TOP (@ChunkSize)
                [ie]
            FROM
                [dbo].[int_encounter] AS [ie]
            WHERE
                [ie].[monitor_created] IS NULL -- Generally created by Admit, Discharge, Transfer (ADT)
                AND DATEDIFF(DAY, [ie].[mod_dt], GETDATE()) > 30; -- delete records that were never admitted to a device which are older than 30 days

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END;
    END TRY
    BEGIN CATCH
        SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        SET @ErrorNumber = ERROR_NUMBER();
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

        --CONTINUE;
    END CATCH;
    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_encounter',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Purge encounter data which is no longer needed or allowed by licensing.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_Encounter_Data';

