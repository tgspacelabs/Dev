﻿CREATE PROCEDURE [dbo].[usp_SaveWaveformDataSet]
    (
     @waveformData [dbo].[WaveformDataType] READONLY
    )
AS
BEGIN
    SET NOCOUNT ON;

    INSERT  INTO [dbo].[WaveformData]
            ([Id],
             [SampleCount],
             [TypeName],
             [TypeId],
             [Samples],
             [Compressed],
             [TopicSessionId],
             [StartTimeUTC],
             [EndTimeUTC])
    SELECT
        [wd].[Id],
        [wd].[SampleCount],
        [wd].[TypeName],
        [wd].[TypeId],
        [wd].[Samples],
        [wd].[Compressed],
        [wd].[TopicSessionId],
        [wd].[StartTimeUTC],
        [wd].[EndTimeUTC]
    FROM
        @waveformData AS [wd]
    ORDER BY
        [wd].[StartTimeUTC];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_SaveWaveformDataSet';

