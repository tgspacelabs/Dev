﻿CREATE PROCEDURE [dbo].[RetrieveBeatTimeLog]
    (
     @UserID [dbo].[DUSER_ID], -- TG - Should be UNIQUEIDENTIFIER
     @PatientId [dbo].[DPATIENT_ID] -- TG - Should be UNIQUEIDENTIFIER
    )
AS
BEGIN
    SELECT
        [ibtl].[user_id],
        [ibtl].[patient_id],
        [ibtl].[start_ft],
        [ibtl].[num_beats],
        [ibtl].[sample_rate],
        [ibtl].[beat_data]
    FROM
        [dbo].[int_beat_time_log] AS [ibtl]
    WHERE
        [ibtl].[user_id] = CAST(@UserID AS UNIQUEIDENTIFIER)
        AND [ibtl].[patient_id] = CAST(@PatientId AS UNIQUEIDENTIFIER);
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'RetrieveBeatTimeLog';

