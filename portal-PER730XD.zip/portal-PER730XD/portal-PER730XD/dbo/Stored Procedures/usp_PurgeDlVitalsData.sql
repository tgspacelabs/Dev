﻿CREATE PROCEDURE [dbo].[usp_PurgeDlVitalsData]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @RowCount INT = @ChunkSize;
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @DateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    
    EXEC [dbo].[PurgerParameters]
        @Name = 'MonitorResults',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;
    SET @PurgeDateUTC = [dbo].[fnLocalDateTimeToUtcTime](@PurgeDate);
    --SET @PurgeDateUTC = DATEADD(HOUR, 1, [dbo].[fnLocalDateTimeToUtcTime](@PurgeDate)); -- add 1 hour as fnLocalDateTimeToUtcTime does not handle daylight savings shift well

    WHILE (@RowCount > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [vd]
            FROM
                [dbo].[VitalsData] AS [vd] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [vd].[TimestampUTC] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'VitalsData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @RowCount = @ChunkSize;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@RowCount > 0)
    BEGIN
        BEGIN TRY 
            DELETE TOP (@ChunkSize)
                [sd]
            FROM
                [dbo].[StatusData] AS [sd] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [sd].[SetId] IN (SELECT
                                    [sds].[Id]
                                 FROM
                                    [dbo].[StatusDataSets] AS [sds]
                                 WHERE
                                    [sds].[TimestampUTC] < @PurgeDateUTC);

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'StatusData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @RowCount = @ChunkSize;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@RowCount > 0)
    BEGIN
        BEGIN TRY 
            DELETE TOP (@ChunkSize)
                [sds]
            FROM
                [dbo].[StatusDataSets] AS [sds] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [sds].[TimestampUTC] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'StatusDataSets',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured UTC time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDateUTC, 121)) + '.');
END;
GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Purge data loader vitals data.',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'usp_PurgeDlVitalsData';

