﻿CREATE PROCEDURE [dbo].[usp_HL7_GetPatientVisitInformation]
    (
     @patient_id UNIQUEIDENTIFIER,
     @monitor_id [dbo].[MonitorIdTable] READONLY
    )
AS
BEGIN
    SET NOCOUNT ON;

    IF ((SELECT
            COUNT(*)
         FROM
            @monitor_id
        ) > 0
        AND @patient_id IS NOT NULL)
    BEGIN
        SELECT TOP (1)
            [ie].[patient_type_cid] AS [PatientType],
            [ie].[med_svc_cid] AS [HospService],
            [ie].[patient_class_cid] AS [PatientClass],
            [ie].[ambul_status_cid] AS [AmbulatorySts],
            [ie].[vip_sw] AS [VipIndic],
            [ie].[discharge_dispo_cid] AS [DischDisposition],
            [ie].[admit_dt] AS [AdmitDate],
            [ie].[discharge_dt] AS [DischargeDt],
            [iem].[encounter_xid] AS [VisitNumber],
            [iem].[seq_no] AS [SeqNo],
            [im].[monitor_name] AS [NodeName],
            [im].[node_id] AS [NodeId],
            [im].[room] AS [Room],
            [im].[bed_cd] AS [Bed],
            [io].[organization_cd] AS [UnitName]
        FROM
            [dbo].[int_encounter] AS [ie]
            INNER JOIN [dbo].[int_encounter_map] AS [iem]
                ON [ie].[encounter_id] = [iem].[encounter_id]
            INNER JOIN [dbo].[int_patient_monitor] AS [patMon]
                ON [patMon].[encounter_id] = [ie].[encounter_id]
                   AND [patMon].[active_sw] = 1
            INNER JOIN [dbo].[int_monitor] AS [im]
                ON [patMon].[monitor_id] = [im].[monitor_id]
            INNER JOIN [dbo].[int_organization] AS [io]
                ON [io].[organization_id] = [im].[unit_org_id]
        WHERE
            [patMon].[patient_id] = @patient_id
            AND [im].[monitor_id] IN (SELECT
                                        [Monitor_Id]
                                      FROM
                                        @monitor_id)
        UNION ALL
        SELECT DISTINCT
            [PatientType] = CAST(NULL AS INT),
            [HospService] = CAST(NULL AS INT),
            [PatientClass] = CAST(NULL AS INT),
            [AmbulatorySts] = CAST(NULL AS INT),
            [VipIndic] = CAST(NULL AS NCHAR(2)),
            [DischDisposition] = CAST(NULL AS INT),
            [ADMIT_TIME].[LocalDateTime] AS [AdmitDate],
            [DISCHARGED_TIME].[LocalDateTime] AS [DischargeDt],
            [VisitNumber] = CAST(NULL AS NVARCHAR(40)),
            [SeqNo] = CAST(NULL AS INT),
            [NodeName] = [vps].[MONITOR_NAME],
            [NodeId] = CAST(NULL AS NVARCHAR(15)),
            [Room] = [vps].[ROOM],
            [Bed] = [vps].[BED],
            [UnitName] = [vps].[UNIT_NAME]
        FROM
            [dbo].[v_PatientSessions] AS [vps]
            CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[ADMIT_TIME_UTC]) AS [ADMIT_TIME]
            CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[DISCHARGED_TIME_UTC]) AS [DISCHARGED_TIME]
        WHERE
            [vps].[patient_id] = @patient_id
            AND [vps].[PATIENT_MONITOR_ID] IN (SELECT
                                                [Monitor_Id]
                                               FROM
                                                @monitor_id)
        ORDER BY
            [AdmitDate] DESC;
    END;
    ELSE
    BEGIN
        SELECT TOP (1)
            [ie].[patient_type_cid] AS [PatientType],
            [ie].[med_svc_cid] AS [HospService],
            [ie].[patient_class_cid] AS [PatientClass],
            [ie].[ambul_status_cid] AS [AmbulatorySts],
            [ie].[vip_sw] AS [VipIndic],
            [ie].[discharge_dispo_cid] AS [DischDisposition],
            [ie].[admit_dt] AS [AdmitDate],
            [ie].[discharge_dt] AS [DischargeDt],
            [iem].[encounter_xid] AS [VisitNumber],
            [iem].[seq_no] AS [SeqNo],
            [im].[monitor_name] AS [NodeName],
            [im].[node_id] AS [NodeId],
            [im].[room] AS [Room],
            [im].[bed_cd] AS [Bed],
            [io].[organization_cd] AS [UnitName]
        FROM
            [dbo].[int_encounter] AS [ie]
            INNER JOIN [dbo].[int_encounter_map] AS [iem]
                ON [ie].[encounter_id] = [iem].[encounter_id]
            INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
                ON [ipm].[encounter_id] = [ie].[encounter_id]
                   AND [ipm].[active_sw] = 1
            INNER JOIN [dbo].[int_monitor] AS [im]
                ON [ipm].[monitor_id] = [im].[monitor_id]
            INNER JOIN [dbo].[int_organization] AS [io]
                ON [io].[organization_id] = [im].[unit_org_id]
        WHERE
            [ipm].[patient_id] = @patient_id
        UNION ALL
        SELECT DISTINCT
            CAST(NULL AS INT) AS [PatientType],
            CAST(NULL AS INT) AS [HospService],
            CAST(NULL AS INT) AS [PatientClass],
            CAST(NULL AS INT) AS [AmbulatorySts],
            CAST(NULL AS NCHAR(2)) AS [VipIndic],
            CAST(NULL AS INT) AS [DischDisposition],
            [ADMIT_TIME].[LocalDateTime] AS [AdmitDate],
            [DISCHARGED_TIME].[LocalDateTime] AS [DischargeDt],
            CAST(NULL AS NVARCHAR(40)) AS [VisitNumber],
            CAST(NULL AS INT) AS [SeqNo],
            [vps].[MONITOR_NAME] AS [NodeName],
            CAST(NULL AS NVARCHAR(15)) AS [NodeId],
            [vps].[ROOM] AS [Room],
            [vps].[BED] AS [Bed],
            [vps].[UNIT_NAME] AS [UnitName]
        FROM
            [dbo].[v_PatientSessions] AS [vps]
            CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[ADMIT_TIME_UTC]) AS [ADMIT_TIME]
            CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[DISCHARGED_TIME_UTC]) AS [DISCHARGED_TIME]
        WHERE
            [vps].[patient_id] = @patient_id
        ORDER BY
            [AdmitDate] DESC;
    END;
END;

GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Get patient visit data.  1) Query by Patient Id  2) Query by Patient Id and Monitor Id',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'usp_HL7_GetPatientVisitInformation';

