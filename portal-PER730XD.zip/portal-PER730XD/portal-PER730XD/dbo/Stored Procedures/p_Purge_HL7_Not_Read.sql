﻿CREATE PROCEDURE [dbo].[p_Purge_HL7_Not_Read] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @GrandTotal INT = 0;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    
    EXEC [dbo].[PurgerParameters]
        @Name = 'HL7NotRead',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;

    /* HL7 NOT READ */
    /* Fix for CR #2676 by Nancy on 1/16/08, Fail to purge due to sent_dt is null */
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [dbo].[int_msg_log]
            FROM
                [dbo].[HL7_out_queue]
            WHERE
                [msg_no] = [external_id]
                AND [msg_status] = N'N'
                AND ([sent_dt] < @PurgeDate
                     OR [queued_dt] < @PurgeDate);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_msg_log',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [dbo].[HL7_msg_ack]
            FROM
                [dbo].[HL7_out_queue] AS [HL7OQ]
            WHERE
                [msg_control_id] = [HL7OQ].[msg_no]
                AND [HL7OQ].[msg_status] = N'N'
                AND ([HL7OQ].[sent_dt] < @PurgeDate
                     OR [HL7OQ].[queued_dt] < @PurgeDate);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'HL7_msg_ack',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [iml]
            FROM
                [dbo].[int_msg_log] AS [iml]
            WHERE
                [iml].[external_id] IN (SELECT
                                            CONVERT(VARCHAR(20), [him].[MessageNo])
                                        FROM
                                            [dbo].[HL7InboundMessage] AS [him]
                                        WHERE
                                            [him].[MessageStatus] = N'N'
                                            AND [him].[MessageProcessedDate] < @PurgeDate);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_msg_log',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [hoq]
            FROM
                [dbo].[HL7_out_queue] AS [hoq]
            WHERE
                [hoq].[msg_status] = N'N'
                AND ([hoq].[sent_dt] < @PurgeDate
                     OR [hoq].[queued_dt] < @PurgeDate);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'HL7_out_queue',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [hpl]
            FROM
                [dbo].[HL7PatientLink] AS [hpl]
            WHERE
                [MessageNo] IN (SELECT
                                    [him].[MessageNo]
                                FROM
                                    [dbo].[HL7InboundMessage] AS [him]
                                WHERE
                                    [him].[MessageStatus] = N'N'
                                    AND [him].[MessageProcessedDate] < @PurgeDate);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'HL7PatientLink',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [him]
            FROM
                [dbo].[HL7InboundMessage] AS [him]
            WHERE
                [him].[MessageStatus] = N'N'
                AND [him].[MessageProcessedDate] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'HL7InboundMessage',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_HL7_Not_Read';

