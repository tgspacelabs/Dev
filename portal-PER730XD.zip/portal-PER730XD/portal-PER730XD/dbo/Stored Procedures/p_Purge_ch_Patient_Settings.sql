﻿CREATE PROCEDURE [dbo].[p_Purge_ch_Patient_Settings] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    --DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @MessageDateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    
    EXEC [dbo].[PurgerParameters]
        @Name = 'CHPATSETTINGS',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [cvp]
            FROM
                [dbo].[cfgValuesPatient] AS [cvp]
            WHERE
                [cvp].[timestamp] < @PurgeDate
                AND [cvp].[patient_id] NOT IN (SELECT
                                                [ie].[patient_id]
                                               FROM
                                                [dbo].[int_encounter] AS [ie]
                                               WHERE
                                                [ie].[discharge_dt] IS NULL);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @MessageDateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'cfgValuesPatient',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CH Patient Settings purge', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_ch_Patient_Settings';

