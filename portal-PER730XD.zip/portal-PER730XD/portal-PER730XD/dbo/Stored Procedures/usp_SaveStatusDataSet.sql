﻿CREATE PROCEDURE [dbo].[usp_SaveStatusDataSet]
    (
     @statusData [dbo].NameValueDataSetType READONLY
    )
AS
BEGIN
    SET NOCOUNT ON;

    INSERT  INTO [dbo].[StatusDataSets]
            ([Id],
             [TopicSessionId],
             [FeedTypeId],
             [TimestampUTC])
    SELECT DISTINCT
        [SetId] AS [Id],
        [TopicSessionId],
        [FeedTypeId],
        [TimestampUTC]
    FROM
        @statusData;

    INSERT  INTO [dbo].[StatusData]
            ([SetId],
             [Name],
             [Value])
    SELECT
        [SetId],
        [Name],
        [Value]
    FROM
        @statusData;
END;
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Save status data.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_SaveStatusDataSet';

