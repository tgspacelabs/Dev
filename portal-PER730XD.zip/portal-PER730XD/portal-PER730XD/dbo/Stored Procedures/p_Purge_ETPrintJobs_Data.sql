﻿CREATE PROCEDURE [dbo].[p_Purge_ETPrintJobs_Data] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    
    EXEC [dbo].[PurgerParameters]
        @Name = 'PrintJob',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;
    
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            -- Delete alarm data
            DELETE TOP (@ChunkSize)
                [ipjet]
            FROM
                [dbo].[int_print_job_et_alarm] AS [ipjet]
            WHERE
                [ipjet].[RowLastUpdatedOn] <= @PurgeDate
                AND [ipjet].[AlarmEndTimeUTC] IS NOT NULL;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_print_job_et_alarm',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    -- Delete vitals data
    SELECT DISTINCT
        [Vitals].[Id]
    INTO
        [#vitalsToDelete]
    FROM
        [dbo].[int_print_job_et_vitals] AS [Vitals]
        LEFT OUTER JOIN [dbo].[int_print_job_et_alarm] AS [Alarm]
            ON [Vitals].[TopicSessionId] = [Alarm].[TopicSessionId]
               AND [Vitals].[ResultTimeUTC] >= [Alarm].[AlarmStartTimeUTC]
               AND [Vitals].[ResultTimeUTC] <= [Alarm].[AlarmEndTimeUTC]
    WHERE
        [Alarm].[TopicSessionId] IS NULL; -- We only want the Ids where there is no corresponding Alarm

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ipjet]
            FROM
                [dbo].[int_print_job_et_vitals] AS [ipjet]
            WHERE
                [Id] IN (SELECT
                            [Id]
                         FROM
                            [#vitalsToDelete]);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_print_job_et_vitals',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    -- Delete waveform data
    SELECT
        [Waveform].[Id]
    INTO
        [#waveformsToDelete]
    FROM
        [dbo].[int_print_job_et_waveform] AS [Waveform]
        LEFT OUTER JOIN [dbo].[int_print_job_et_alarm] AS [Alarm]
            ON [Waveform].[DeviceSessionId] = [Alarm].[DeviceSessionId]
               AND [Waveform].[StartTimeUTC] < [Alarm].[AlarmEndTimeUTC]
               AND [Waveform].[EndTimeUTC] > [Alarm].[AlarmStartTimeUTC]
    WHERE
        [Alarm].[TopicSessionId] IS NULL; -- We only want the Ids where there is no corresponding Alarm

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ipjet]
            FROM
                [dbo].[int_print_job_et_waveform] AS [ipjet]
            WHERE
                [Id] IN (SELECT
                            [Id]
                         FROM
                            [#waveformsToDelete]);

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_print_job_et_waveform',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Purges old alarm report data previously saved for ET Print Jobs.  Used by the ICS_PurgeData SqlAgentJob.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_ETPrintJobs_Data';

