﻿CREATE PROCEDURE [dbo].[usp_HL7_GetLegacyGdsCodes]
AS
BEGIN
    SELECT
        [imc].[code_id] AS [CodeId],
        [imc].[code] AS [Gds_Code],
        [imc].[short_dsc] AS [Gds_Description],
        [imc].[int_keystone_cd] AS [Gds_UoM]
    FROM
        [dbo].[int_misc_code] AS [imc];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Retrieve the legacy Gds codes.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_HL7_GetLegacyGdsCodes';

