﻿CREATE PROCEDURE [dbo].[usp_Get_AuditLogDefault]
AS
BEGIN
    SELECT
        ISNULL([ial].[login_id], N'') AS [Login ID],
        [ial].[application_id] AS [Application],
        [ial].[device_name] AS [Location],
        [ial].[audit_dt] AS [Date],
        [imm].[mrn_xid] AS [Patient ID],
        [imc].[short_dsc] AS [Event],
        [ial].[audit_descr] AS [Description]
    FROM
        [dbo].[int_audit_log] AS [ial]
        LEFT OUTER JOIN [dbo].[int_mrn_map] AS [imm]
            ON [ial].[patient_id] = [imm].[mrn_xid]
        INNER JOIN [dbo].[int_misc_code] AS [imc]
            ON [imc].[code] = [ial].[audit_type];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_Get_AuditLogDefault';

