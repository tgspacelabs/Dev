﻿CREATE PROCEDURE [dbo].[usp_RemoveTrailingLiveWaveformData]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @Message VARCHAR(200) = '';
    DECLARE @PurgeDate DATETIME = SYSDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @Flag BIT = 1;
    DECLARE @RowCount BIGINT = 0;
    DECLARE @TotalRows BIGINT = 0;
    DECLARE @GrandTotal BIGINT = 0;
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @Multiplier TINYINT = 10;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Starting WaveformLiveData purge...';
        RAISERROR (@Message, 10, 1) WITH NOWAIT;

        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Chunk Size: %d', 10, 1, @DateString, @ChunkSize) WITH NOWAIT;
    END;

    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [wld]
            FROM
                [dbo].[WaveformLiveData] AS [wld] WITH (ROWLOCK) -- Do not allow lock escalations.
                INNER JOIN (SELECT
                                [wld2].[TopicInstanceId],
                                [wld2].[TypeId],
                                MAX([wld2].[EndTimeUTC]) AS [LatestUTC]
                            FROM
                                [dbo].[WaveformLiveData] AS [wld2] WITH (ROWLOCK) -- Do not allow lock escalations.
                            GROUP BY
                                [wld2].[TopicInstanceId],
                                [wld2].[TypeId]
                           ) AS [cr]
                    ON [wld].[TopicInstanceId] = [cr].[TopicInstanceId]
                       AND [wld].[TypeId] = [cr].[TypeId]
            WHERE
                [wld].[StartTimeUTC] < [cr].[LatestUTC];

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            WAITFOR DELAY '00:00:01';
    
            CONTINUE;
        END CATCH;

        IF (@Debug = 1)
        BEGIN
        -- Report progress when Total Rows is a multiple of Chunk Size
            IF (@TotalRows % (@ChunkSize * @Multiplier) = 0)
            BEGIN
                SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
            END;
        END;

        IF (@RowCount = 0)
            SET @Flag = 0;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'WaveformLiveData',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d', 10, 1, @DateString, @TotalRows) WITH NOWAIT;

        SET @Message = CAST(SYSDATETIME() AS VARCHAR(40)) + ' - Ending WaveformLiveData purge...';
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured UTC time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Remove the waveform live data where start times are less than the latest end times per topic instance ID.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_RemoveTrailingLiveWaveformData';

