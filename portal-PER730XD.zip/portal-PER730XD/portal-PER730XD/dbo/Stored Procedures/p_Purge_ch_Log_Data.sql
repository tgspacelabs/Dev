﻿CREATE PROCEDURE [dbo].[p_Purge_ch_Log_Data] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    --DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);

    EXEC [dbo].[PurgerParameters]
        @Name = 'CHLOGDATA',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;

    IF (@Debug = 1)
    BEGIN
        DECLARE @MessageDateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));
        DECLARE @Message VARCHAR(200) = '';
        DECLARE @Multiple TINYINT = 10;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Starting...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    --Purge data from logData too on 2/28/08
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ld]
            FROM
                [dbo].[LogData] AS [ld]
            WHERE
                [ld].[DateTime] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @MessageDateString, @TotalRows) WITH NOWAIT;
                END;
            END;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    IF (@Debug = 1)
    BEGIN
        IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
        BEGIN
            SET @MessageDateString = CAST(SYSDATETIME() AS VARCHAR(30));
            RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @MessageDateString, @TotalRows) WITH NOWAIT;
        END;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'LogData',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_ch_Log_Data';

