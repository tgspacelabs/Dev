﻿CREATE PROCEDURE [dbo].[usp_GetPatientList]
    (
     @filters NVARCHAR(MAX),
     @showADTEncounters BIT,
     @Debug BIT = 0
    )
AS
BEGIN
    DECLARE @QUERY NVARCHAR(MAX);

    SET @QUERY = N'
SELECT
    [vce].[FIRST_NAME] AS [First Name],
    [vce].[LAST_NAME] AS [Last Name],
    [vce].[MRN_ID] AS [Patient ID],
    [vce].[ACCOUNT_ID] AS [Patient ID2],
    [vce].[DOB] AS [DOB],
    [vce].[FACILITY_ID],
    [vce].[UNIT_ID],
    [vce].[ROOM],
    [vce].[BED],
    [vce].[MONITOR_NAME] AS [Device],
    [vce].[LAST_RESULT] AS [Last Result],
    [vce].[ADMIT] AS [Admitted],
    [vce].[DISCHARGED] AS [Discharged],
    [vce].[SUBNET] AS [Subnet],
    [vce].[patient_id] AS [GUID],
    [vce].[FACILITY_PARENT_ID] AS [parent_organization_id]
INTO
    [#CombinedEncounters]
FROM
    [dbo].[v_CombinedEncounters] AS [vce]
WHERE
    [vce].[MERGE_CD] = ''C''
    AND [vce].[PATIENT_MONITOR_ID] IS NOT NULL
    AND [vce].[MONITOR_CREATED] = 1';

    IF (@showADTEncounters <> 1)
    BEGIN 
        SET @QUERY += N' AND [vce].[PATIENT_MONITOR_ID] IS NOT NULL AND [vce].[MONITOR_CREATED] = 1';
    END;
                                                                
    IF (LEN(@filters) > 0)
    BEGIN
        SET @QUERY += N' AND ' + @filters;
    END;

    SET @QUERY += N';';

    SET @QUERY += N'
SELECT
    [ce].[First Name],
    [ce].[Last Name],
    [ce].[Patient ID],
    [ce].[Patient ID2],
    [ce].[DOB],
    RTRIM(ISNULL([org1].[organization_cd], N''-'') + N'' '' + ISNULL([org2].[organization_cd], N''-'') + N'' '' + ISNULL([ce].[ROOM], N''-'') + N'' '' + ISNULL([ce].[BED], N''-'')) AS [Location],
    [ce].[Device],
    [ce].[Last Result],
    [ce].[Admitted],
    [ce].[Discharged],
    [ce].[Subnet],
    [ce].[GUID],
    [ce].[parent_organization_id]
FROM
    [#CombinedEncounters] AS [ce]
    INNER JOIN [dbo].[int_organization] AS [org1]
        ON [org1].[organization_id] = [ce].[FACILITY_ID]
    INNER JOIN [dbo].[int_organization] AS [org2]
        ON [org2].[organization_id] = [ce].[UNIT_ID]
OPTION (RECOMPILE);';

    IF (@Debug = 1)
    BEGIN
        PRINT @QUERY;
    END;

    EXEC(@QUERY);
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_GetPatientList';

