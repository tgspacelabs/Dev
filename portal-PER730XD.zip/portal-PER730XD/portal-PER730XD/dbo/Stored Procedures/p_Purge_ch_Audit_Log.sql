﻿CREATE PROCEDURE [dbo].[p_Purge_ch_Audit_Log] 
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    --DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @TotalRows INT = 0;
    DECLARE @GrandTotal INT = 0;
    DECLARE @Loop INT = 1;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @DateString VARCHAR(30) = CAST(@PurgeDate AS VARCHAR(30));
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);

    EXEC [dbo].[PurgerParameters]
        @Name = 'CHAUDITLOG',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;

    --Purge data from int_audit_log too on 2/28/08
    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ial]
            FROM
                [dbo].[int_audit_log] AS [ial]
            WHERE
                [ial].[audit_dt] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'int_audit_log',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @Loop = 1;
    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @StartTime = SYSUTCDATETIME();

    WHILE (@Loop > 0)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [ald]
            FROM
                [dbo].[AuditLogData] AS [ald]
            WHERE
                [ald].[DateTime] < @PurgeDate;

            SET @Loop = @@ROWCOUNT;
            SET @TotalRows += @Loop;
        END TRY
        BEGIN CATCH
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'AuditLogData',
        @PurgeDate = @PurgeDate,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured local time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDate, 121)) + '.');
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CH Audit Logs purge.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'p_Purge_ch_Audit_Log';

