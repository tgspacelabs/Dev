﻿CREATE PROCEDURE [dbo].[usp_GetAllProducts]
AS
BEGIN
    SELECT
        [ip].[product_cd],
        [ip].[descr],
        [ip].[has_access]
    FROM
        [dbo].[int_product] AS [ip]
    ORDER BY
        [ip].[product_cd];
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_GetAllProducts';

