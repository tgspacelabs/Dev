﻿CREATE PROCEDURE [dbo].[usp_SaveDeviceInfoDataSet]
    (
     @deviceInfoData [dbo].[DeviceInfoDataSetType] READONLY
    )
AS
BEGIN
    SET NOCOUNT ON;

    INSERT  INTO [dbo].[DeviceInfoData]
            (--[Id], -- Remove once the code which provides this value is updated - TG
             [DeviceSessionId],
             [Name],
             [Value],
             [TimestampUTC])
    SELECT
        --[did].[Id], -- Remove once the code which provides this value is updated - TG
        [did].[DeviceSessionId],
        [did].[Name],
        [did].[Value],
        [did].[TimestampUTC]
    FROM
        @deviceInfoData AS [did];
	
	/* If a patient admit was pending on the device org assignment arrival, then we
	   create the mrn_map row here.  The patient id might be already bound to the
	   patient session or not */
    MERGE INTO [dbo].[int_mrn_map] AS [Dest]
    USING
        (SELECT
            [PatientId] = ISNULL([PatientSessionsMapSequence].[PatientId], NEWID()),
            [FacilityId] = [Facilities].[organization_id],
            [ID1] = [LatestPatientData].[ID1],
            [ID2] = [LatestPatientData].[ID2]
         FROM
            (SELECT
                [DeviceSessionFacilitySequence].[DeviceSessionId],
                CASE WHEN CHARINDEX('+', [DeviceSessionFacilitySequence].[Value]) > 0
                     THEN LEFT([DeviceSessionFacilitySequence].[Value], CHARINDEX('+', [DeviceSessionFacilitySequence].[Value]) - 1)
                     ELSE NULL
                END AS [FacilityValue]
             FROM
                (SELECT
                    [did].[DeviceSessionId],
                    [did].[Value],
                    ROW_NUMBER() OVER (PARTITION BY [did].[DeviceSessionId] ORDER BY [did].[TimestampUTC] DESC) AS [RowNumber]
                 FROM
                    @deviceInfoData AS [did]
                 WHERE
                    [did].[Name] = 'Unit'
                ) AS [DeviceSessionFacilitySequence]
             WHERE
                [DeviceSessionFacilitySequence].[RowNumber] = 1
            ) AS [LatestDeviceSessionFacility]
            INNER JOIN [dbo].[int_organization] AS [Facilities]
                ON [Facilities].[category_cd] = 'F'
                   AND [Facilities].[organization_nm] = [LatestDeviceSessionFacility].[FacilityValue]
            INNER JOIN (SELECT
                            [PatientDataSequence].[PatientSessionId],
                            [PatientDataSequence].[DeviceSessionId],
                            [PatientDataSequence].[ID1],
                            [PatientDataSequence].[ID2]
                        FROM
                            (SELECT
                                [pd].[PatientSessionId],
                                [pd].[DeviceSessionId],
                                [pd].[ID1],
                                [pd].[ID2],
                                ROW_NUMBER() OVER (PARTITION BY [pd].[PatientSessionId] ORDER BY [pd].[TimestampUTC] DESC) AS [RowNumber]
                             FROM
                                [dbo].[PatientData] AS [pd]
                            ) AS [PatientDataSequence]
                        WHERE
                            [PatientDataSequence].[RowNumber] = 1
                            AND [PatientDataSequence].[ID1] IS NOT NULL
                       ) AS [LatestPatientData]
                ON [LatestPatientData].[DeviceSessionId] = [LatestDeviceSessionFacility].[DeviceSessionId]
            INNER JOIN (SELECT
                            [psm].[PatientSessionId],
                            [psm].[PatientId],
                            ROW_NUMBER() OVER (PARTITION BY [psm].[PatientSessionId] ORDER BY [psm].[Sequence] DESC) AS [RowNumber]
                        FROM
                            [dbo].[PatientSessionsMap] AS [psm]
                       ) AS [PatientSessionsMapSequence]
                ON [PatientSessionsMapSequence].[RowNumber] = 1
                   AND [PatientSessionsMapSequence].[PatientSessionId] = [LatestPatientData].[PatientSessionId]
        ) AS [Src]
    ON [Src].[PatientId] = [Dest].[patient_id]
        AND [Dest].[merge_cd] = 'C'
    WHEN NOT MATCHED BY TARGET THEN
        INSERT
               ([organization_id],
                [mrn_xid],
                [patient_id],
                [merge_cd],
                [mrn_xid2])
        VALUES ([Src].[FacilityId],
                [Src].[ID1],
                [Src].[PatientId],
                'C',
                [Src].[ID2]);
END;

GO


