﻿CREATE PROCEDURE [dbo].[usp_PurgeDlAlarmData]
    (
     @ChunkSize INT = 1500,
     @Debug BIT = 0
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PurgeDate DATETIME;
    DECLARE @PurgeDateUTC DATETIME;
    DECLARE @Procedure NVARCHAR(255) = OBJECT_NAME(@@PROCID);
    DECLARE @Flag BIT = 1;
    DECLARE @RowCount INT = 0;
    DECLARE @TotalRows BIGINT = 0;
    DECLARE @GrandTotal BIGINT = 0;
    DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();
    DECLARE @ErrorNumber INT = 0;
    DECLARE @ErrorMessage NVARCHAR(MAX);
    DECLARE @DateString VARCHAR(30) = CAST(SYSUTCDATETIME() AS VARCHAR(30));

    EXEC [dbo].[PurgerParameters]
        @Name = 'Alarm',
        @PurgeDate = @PurgeDate OUTPUT,
        @ChunkSize = @ChunkSize OUTPUT;
    SET @PurgeDateUTC = DATEADD(HOUR, 1, [dbo].[fnLocalDateTimeToUtcTime](@PurgeDate)); -- add 1 hour as fnLocalDateTimeToUtcTime does not handle daylight savings shift well
    
    IF (@Debug = 1)
    BEGIN
        DECLARE @Message VARCHAR(200) = '';
        DECLARE @Multiple TINYINT = 10;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Starting...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [gad]
            FROM
                [dbo].[GeneralAlarmsData] AS [gad] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [gad].[StartDateTime] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
                END;
            END;

            IF (@RowCount = 0)
                SET @Flag = 0;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'GeneralAlarmsData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @Flag = 1;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [lad]
            FROM
                [dbo].[LimitAlarmsData] AS [lad] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [lad].[StartDateTime] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
                END;
            END;

            IF (@RowCount = 0)
                SET @Flag = 0;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'LimitAlarmsData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @Flag = 1;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [lcd]
            FROM
                [dbo].[LimitChangeData] AS [lcd] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [lcd].[AcquiredDateTimeUTC] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
                END;
            END;

            IF (@RowCount = 0)
                SET @Flag = 0;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'LimitChangeData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;
    SET @TotalRows = 0;
    SET @Flag = 1;
    SET @StartTime = SYSUTCDATETIME();
    
    WHILE (@Flag = 1)
    BEGIN
        BEGIN TRY
            DELETE TOP (@ChunkSize)
                [asd]
            FROM
                [dbo].[AlarmsStatusData] AS [asd] WITH (ROWLOCK) -- Do not allow lock escalations.
            WHERE
                [asd].[AcquiredDateTimeUTC] < @PurgeDateUTC;

            SET @RowCount = @@ROWCOUNT;
            SET @TotalRows += @RowCount;

            IF (@Debug = 1)
            BEGIN
                IF (@TotalRows % (@ChunkSize * @Multiple) = 0) -- When Total Rows is a multiple of Chunk Size
                BEGIN
                    SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
                    RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
                END;
            END;

            IF (@RowCount = 0)
                SET @Flag = 0;
        END TRY
        BEGIN CATCH
            SET @DateString = CAST(SYSUTCDATETIME() AS VARCHAR(30));
            SET @ErrorNumber = ERROR_NUMBER();
            SET @ErrorMessage = ERROR_MESSAGE();
            RAISERROR (N'%s - ERROR: %d - CONTINUING...', 10, 1, @DateString, @ErrorNumber) WITH NOWAIT;

            CONTINUE;
        END CATCH;
    END;

    IF (@Debug = 1)
    BEGIN
        SET @DateString = CAST(SYSDATETIME() AS VARCHAR(30));
        RAISERROR (N'%s - Total Rows Deleted: %I64d ...', 10, 1, @DateString, @TotalRows) WITH NOWAIT;
    END;

    EXEC [dbo].[uspInsertPurgerLog]
        @Procedure = @Procedure,
        @Table = N'AlarmsStatusData',
        @PurgeDate = @PurgeDateUTC,
        @Parameters = '',
        @ChunkSize = @ChunkSize,
        @Rows = @TotalRows,
        @ErrorNumber = @ErrorNumber,
        @ErrorMessage = @ErrorMessage,
        @StartTime = @StartTime;

    SET @GrandTotal += @TotalRows;

    IF (@Debug = 1)
    BEGIN
        SET @Message = CAST(SYSDATETIME() AS VARCHAR(30)) + ' - Finished...' + @Procedure;
        RAISERROR (@Message, 10, 1) WITH NOWAIT;
    END;

    PRINT (CONVERT(VARCHAR(30), GETDATE(), 121) + ' -- Records (' + CAST(@GrandTotal AS NVARCHAR(20)) + ') purged from ICS (' + @Procedure
           + ') at configured UTC time interval : ' + RTRIM(CONVERT(VARCHAR(30), @PurgeDateUTC, 121)) + '.');
END;
GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Purge DL alarm data.',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'usp_PurgeDlAlarmData';

