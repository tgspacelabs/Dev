﻿CREATE PROCEDURE [dbo].[usp_HL7_GetLiveVitalsAndPatientDataByQuery]
    (
     @QRYItem NVARCHAR(80),
     @type INT = -1
    )
AS
BEGIN
    DECLARE @patient_id UNIQUEIDENTIFIER;

    -- Create the equivalent date time to (GETDATE( ) - 0.002)
    DECLARE @LowerTimeLimit DATETIME = DATEADD(MILLISECOND, -172800, GETDATE());

    SET @patient_id = [dbo].[fn_HL7_GetPatientIdFromQueryItemType](@QRYItem, @type);

    --Person and Patient data for PID
    SELECT DISTINCT
        [ip].[dob] AS [DateOfBirth],
        [ip].[gender_cid] AS [GenderCd],
        [ip].[death_dt] AS [DeathDate],
        [ipe].[first_nm] AS [FirstName],
        [ipe].[middle_nm] AS [MiddleName],
        [ipe].[last_nm] AS [LastName],
        [imm].[mrn_xid2] AS [AccountNumber],
        [imm].[mrn_xid] AS [MRN],
        [imm].[patient_id] AS [patient_id],
        [ipm].[monitor_id] AS [DeviceId]
    FROM
        [dbo].[int_patient] AS [ip]
        INNER JOIN [dbo].[int_person] AS [ipe]
            ON [ip].[patient_id] = [ipe].[person_id]
               AND [ip].[patient_id] = @patient_id
        INNER JOIN [dbo].[int_mrn_map] AS [imm]
            ON [ip].[patient_id] = [imm].[patient_id]
        INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
            ON [ip].[patient_id] = [ipm].[patient_id]
    WHERE
        [imm].[merge_cd] = 'C'
    UNION ALL
    SELECT
        NULL AS [DateOfBirth],
        NULL AS [GenderCd],
        NULL AS [DeathDate],
        [vps].[FIRST_NAME] AS [FirstName],
        [vps].[MIDDLE_NAME] AS [MiddleName],
        [vps].[LAST_NAME] AS [LastName],
        [vps].[ACCOUNT_ID] AS [AccountNumber],
        [vps].[MRN_ID] AS [MRN],
        [vps].[patient_id],
        [vps].[DeviceId]
    FROM
        [dbo].[v_PatientSessions] AS [vps]
    WHERE
        [vps].[patient_id] = @patient_id
        AND [vps].[STATUS] = 'A'; -- Per Alex Beechie - Bug # 10012

    --Get Order data
    SELECT TOP (1)
        [OrderNumber].[Value] AS [ORDER_ID],
        [ig].[send_app] AS [SENDING_APPLICATION],
        CAST([OrderStatus].[Value] AS INT) AS [ORDER_STATUS],
        CAST(NULL AS DATETIME) AS [ORDER_DATE_TIME],
        @patient_id AS [patient_id]
    FROM
        [dbo].[int_gateway] AS [ig]
        CROSS JOIN (SELECT
                        [as].[Value]
                    FROM
                        [dbo].[ApplicationSettings] AS [as]
                    WHERE
                        [as].[Key] = 'DefaultFillerOrderStatus'
                   ) AS [OrderStatus]
        CROSS JOIN (SELECT
                        [as2].[Value]
                    FROM
                        [dbo].[ApplicationSettings] AS [as2]
                    WHERE
                        [as2].[Key] = 'DefaultFillerOrderNumber'
                   ) AS [OrderNumber];

    -- Get OBR
    SELECT DISTINCT
        [OrderNumber].[Value] AS [ORDER_ID],
        [ig].[send_app] AS [SENDING_APPLICATION],
        CAST(NULL AS DATETIME) AS [ORDER_DATE_TIME]
    FROM
        [dbo].[int_gateway] AS [ig]
        CROSS JOIN (SELECT
                        [as].[Value]
                    FROM
                        [dbo].[ApplicationSettings] AS [as]
                    WHERE
                        [as].[Key] = 'DefaultFillerOrderNumber'
                   ) AS [OrderNumber];

    --Patient visit/encounter information
    SELECT
        [ie].[patient_type_cid] AS [PatientType],
        [ie].[med_svc_cid] AS [HospService],
        [ie].[patient_class_cid] AS [PatientClass],
        [ie].[ambul_status_cid] AS [AmbulatorySts],
        [ie].[vip_sw] AS [VipIndic],
        [ie].[discharge_dispo_cid] AS [DischDisposition],
        [ie].[admit_dt] AS [AdmitDate],
        [ie].[discharge_dt] AS [DischargeDt],
        [iem].[encounter_xid] AS [VisitNumber],
        [ie].[patient_id] AS [patient_id],
        [iem].[seq_no] AS [SeqNo],
        [im].[monitor_name] AS [NodeName],
        [im].[node_id] AS [NodeId],
        [im].[room] AS [Room],
        [im].[bed_cd] AS [Bed],
        [io].[organization_cd] AS [UnitName],
        [ipm].[monitor_id] AS [DeviceId]
    FROM
        [dbo].[int_encounter] AS [ie]
        INNER JOIN [dbo].[int_encounter_map] AS [iem]
            ON [ie].[encounter_id] = [iem].[encounter_id]
        INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
            ON [ipm].[encounter_id] = [ie].[encounter_id]
               AND [ipm].[active_sw] = 1
        INNER JOIN [dbo].[int_monitor] AS [im]
            ON [ipm].[monitor_id] = [im].[monitor_id]
        INNER JOIN [dbo].[int_organization] AS [io]
            ON [io].[organization_id] = [im].[unit_org_id]
    WHERE
        [ipm].[patient_id] = @patient_id
        AND [ie].[discharge_dt] IS NULL
    UNION ALL
    SELECT DISTINCT
        CAST(NULL AS INT) AS [PatientType],
        CAST(NULL AS INT) AS [HospService],
        CAST(NULL AS INT) AS [PatientClass],
        CAST(NULL AS INT) AS [AmbulatorySts],
        CAST(NULL AS NCHAR(2)) AS [VipIndic],
        CAST(NULL AS INT) AS [DischDisposition],
        [AdmitDate].[LocalDateTime] AS [AdmitDate],
        [DischargeDt].[LocalDateTime] AS [DischargeDt],
        CAST(NULL AS NVARCHAR(40)) AS [VisitNumber],
        [vps].[patient_id] AS [patient_id],
        CAST(NULL AS INT) AS [SeqNo],
        [vps].[MONITOR_NAME] AS [NodeName],
        CAST(NULL AS NVARCHAR(15)) AS [NodeId],
        [vps].[ROOM] AS [Room],
        [vps].[BED] AS [Bed],
        [vps].[UNIT_NAME] AS [UnitName],
        [vps].[DeviceId] AS [DeviceId]
    FROM
        [dbo].[v_PatientSessions] AS [vps]
        CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[ADMIT_TIME_UTC]) AS [AdmitDate]
        CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([vps].[DISCHARGED_TIME_UTC]) AS [DischargeDt]
    WHERE
        [patient_id] = @patient_id
        AND [vps].[DISCHARGED_TIME_UTC] IS NULL -- Per Alex Beechie - Bug # 10012
    ORDER BY
        [AdmitDate] DESC;

    --Get vitals

    -- For ML patients (Legacy Tele)
    SELECT DISTINCT
        [ivlt].[patient_id] AS [PATID],
        [ivlt].[monitor_id] AS [MONITORID],
        [ivlt].[collect_dt] AS [COLLECTDATE],
        [ivlt].[vital_value] AS [VITALS],
        [ivlt].[vital_time] AS [VITALSTIME],
        [imm].[organization_id] AS [ORGID],
        [imm].[mrn_xid] AS [MRN]
    FROM
        [dbo].[int_vital_live_temp] AS [ivlt]
        INNER JOIN [dbo].[int_mrn_map] AS [imm]
            ON [ivlt].[patient_id] = [imm].[patient_id]
        INNER JOIN [dbo].[int_patient_monitor] AS [ipm]
            ON [ivlt].[patient_id] = [ipm].[patient_id]
               AND [ivlt].[monitor_id] = [ipm].[monitor_id]
    WHERE
        [ivlt].[patient_id] = @patient_id
        AND [imm].[merge_cd] = 'C'
        AND [ivlt].[createdDT] = (SELECT
                                    MAX([ivlt2].[createdDT])
                                  FROM
                                    [dbo].[int_vital_live_temp] AS [ivlt2]
                                  WHERE
                                    [ivlt2].[monitor_id] = [ivlt].[monitor_id]
                                    AND [ivlt2].[patient_id] = [ivlt].[patient_id]
                                    AND [ivlt2].[createdDT] > @LowerTimeLimit
                                 )
    ORDER BY
        [ivlt].[patient_id];

    -- For DL patients
    SELECT
        [VitalsAll].[CodeId],
        [VitalsAll].[GdsCode] AS [Code],
        [VitalsAll].[Description] AS [Descr],
        [VitalsAll].[Units],
        [VitalsAll].[Value] AS [ResultValue],
        N'' AS [ValueTypeCd],
        NULL AS [ResultStatus],
        NULL AS [Probability],
        NULL AS [ReferenceRange],
        NULL AS [AbnormalNatureCd],
        NULL AS [AbnormalCd],
        [ResultTime].[LocalDateTime] AS [ResultTime],
        [VitalsAll].[PatientId] AS [patient_id]
    FROM
        (SELECT
            ROW_NUMBER() OVER (PARTITION BY [vpts].[PatientId], [gcm].[GdsCode] ORDER BY [ld].[TimestampUTC] DESC) AS [RowNumber],
            [ld].[FeedTypeId],
            [ld].[TopicInstanceId],
            [ld].[Name],
            [ld].[Value],
            [gcm].[GdsCode],
            [gcm].[CodeId],
            [gcm].[Units],
            [ld].[TimestampUTC],
            [vpts].[PatientId],
            [gcm].[Description]
         FROM
            [dbo].[LiveData] AS [ld]
            INNER JOIN [dbo].[TopicSessions] AS [ts]
                ON [ts].[TopicInstanceId] = [ld].[TopicInstanceId]
                   AND [ts].[EndTimeUTC] IS NULL
            INNER JOIN [dbo].[GdsCodeMap] AS [gcm]
                ON [gcm].[FeedTypeId] = [ld].[FeedTypeId]
                   AND [gcm].[Name] = [ld].[Name]
            INNER JOIN [dbo].[v_PatientTopicSessions] AS [vpts]
                ON [ts].[Id] = [vpts].[TopicSessionId]
         WHERE
            [vpts].[PatientId] = @patient_id
        ) AS [VitalsAll]
        CROSS APPLY [dbo].[fntUtcDateTimeToLocalTime]([VitalsAll].[TimestampUTC]) AS [ResultTime]
    WHERE
        [VitalsAll].[RowNumber] = 1
        AND [VitalsAll].[Units] IS NOT NULL;
END;

GO
EXECUTE [sys].[sp_addextendedproperty]
    @name = N'MS_Description',
    @value = N'Retrieves the vitals and other patient data of all the active patients to generate the Oru messages',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'usp_HL7_GetLiveVitalsAndPatientDataByQuery';

