﻿CREATE PROCEDURE [dbo].[usp_CEI_GetQueryCode]
AS
BEGIN
    SELECT
        [imc].[code_id],
        [imc].[short_dsc],
        [imc].[int_keystone_cd]
    FROM
        [dbo].[int_misc_code] AS [imc]
    WHERE
        [imc].[method_cd] = N'GDS'
        AND [imc].[verification_sw] IS NOT NULL
        AND [imc].[short_dsc] IS NOT NULL;
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'usp_CEI_GetQueryCode';

