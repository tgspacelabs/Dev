﻿CREATE PROCEDURE [dbo].[GetPatientSavedEventVitals]
    (
     @patient_id AS UNIQUEIDENTIFIER,
     @event_id AS UNIQUEIDENTIFIER,
     @gds_code AS NVARCHAR(80)
    )
AS
BEGIN
    SELECT
        [isv].[result_dt],
        [isv].[result_value]
    FROM
        [dbo].[int_savedevent_vitals] AS [isv]
    WHERE
        [isv].[patient_id] = @patient_id
        AND [isv].[event_id] = @event_id
        AND [isv].[gds_code] = @gds_code;
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'PROCEDURE', @level1name = N'GetPatientSavedEventVitals';

