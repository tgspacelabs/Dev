﻿-- Usage:
-- dbo.GetLegacyPatientVitalSignByChannels stored procedure
-- dbo.GetPatientVitalSignByChannels stored procedure
CREATE FUNCTION [dbo].[fn_Vital_Merge]
    (
     @InputStrings [dbo].[VitalValues] READONLY,
     @sDelim VARCHAR(20) = ' '
    )
RETURNS @retArray TABLE
    (
     [idx] SMALLINT PRIMARY KEY,
     [value] VARCHAR(8000)
    )
    WITH SCHEMABINDING
AS
BEGIN
    DECLARE
        @VitalsCombine VARCHAR(MAX) = '',
        @VitalsPatientRowCount INT = 0;

    SELECT
        @VitalsPatientRowCount = COUNT([is].[VitalValue])
    FROM
        @InputStrings AS [is];

    WHILE (@VitalsPatientRowCount > 0)
    BEGIN
        IF (@VitalsCombine <> '')
        BEGIN
            SET @VitalsCombine += @sDelim + (SELECT
                                                [is].[VitalValue]
                                             FROM
                                                @InputStrings AS [is]
                                             WHERE
                                                [is].[Id] = @VitalsPatientRowCount
                                            );
        END;                                            
        ELSE
        BEGIN
            SET @VitalsCombine = (SELECT
                                    [is].[VitalValue]
                                  FROM
                                    @InputStrings AS [is]
                                  WHERE
                                    [is].[Id] = @VitalsPatientRowCount
                                 );
        END;                                 

        SET @VitalsPatientRowCount -= 1;
    END;

    INSERT  INTO @retArray
            ([idx],
             [value])
    SELECT
        [fs].[idx],
        [fs].[value]
    FROM
        [dbo].[fn_Split](@VitalsCombine, @sDelim) AS [fs];

    RETURN;
END;

GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Merge vital values into a single string.', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'FUNCTION', @level1name = N'fn_Vital_Merge';

