﻿CREATE FUNCTION [dbo].[fntMarkIdAsDuplicate] (@id AS NVARCHAR(15))
RETURNS TABLE
    WITH SCHEMABINDING
    AS
    RETURN
    SELECT
        CASE WHEN @id LIKE N'*_*%'
             THEN CASE WHEN LEFT(@id, 3) = N'***' THEN N'*1*' + SUBSTRING(@id, 4, 12)
                       WHEN SUBSTRING(@id, 2, 1) LIKE N'[0-8]' THEN N'*' + CAST(CAST(SUBSTRING(@id, 2, 1) AS INT) + 1 AS NVARCHAR(15)) + N'*' + RIGHT(@id, 12)
                       ELSE N'***' + RIGHT(@id, 12)
                  END
             ELSE N'***' + RIGHT(@id, 12)
        END AS [DuplicateID];